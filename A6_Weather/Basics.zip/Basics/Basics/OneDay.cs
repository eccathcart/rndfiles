﻿using System;

namespace Basics
{
	public class OneDay
	{
		public OneDay ()
		{
		}
	}
}

